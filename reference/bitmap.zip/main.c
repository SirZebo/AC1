#include <stdio.h>
#include "bitmap.h"
#include "image.h"

int main() {
    char* file = "untitled.bmp";
    Bitmap* bmp = openBitmap(file);
    printf("File size: %d\n", bmp -> fileSize);
    printf("Image Size: %d\n", bmp -> imageSize);
    printf("Bits per pixel: %d\n", bmp -> bitsPerPixel);
    printf("Number of pixel: %d\n", bmp -> height * bmp -> width);

    Image* img = openImage(bmp);
    Image* grey = greyscale(imageCopy(img)); 
    // for (int i = 0; i < 5; i++) {
    //     printf("%d\n", img -> pixels[i].b);
    // }
    // printf("%d\n", getPixel(3, 1, img).b);

    Image* contrast = contrastImage(imageCopy(img), 25);
    printf("%d %d %d\n", getPixel(3, 1, contrast).b, getPixel(3, 1, contrast).g, getPixel(3, 1, contrast).r );
    freeBitMap(bmp);
    freeImage(img);
    freeImage(grey);
    freeImage(contrast);
    
    return 0;
}